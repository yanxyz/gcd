# gcd

WPF 小程序，用于运行 `git clone --depth=1 repo_github_url`。

![](screenshot.png)

[Download](https://pan.baidu.com/s/1miqIlO8)

## License

MIT (c) Ivan Yan
[Source](https://github.com/yanxyz/gcd)
